<?php   

class Sudaapp extends CI_Controller {
    
    

	public function login(){
        $this->load->view('login');

    }
    public function desh(){
        $this->load->view('desh');

    }









}





?>